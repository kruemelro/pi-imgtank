<?php
function is_dir_empty($dir) {
  if (!is_readable($dir)) return NULL; 
  return (count(scandir($dir)) == 2);
}
if (isset($_GET['deleted'])) {
    $mode = 'deleted';
} else {
    $mode = 'confirm';
}
if ($mode == 'confirm') {
    echo "<strong>Welcome to the uninstall script for TheVDM's 'Photo Archive'</strong><br>
    <br>
    This script is to be used for deleting the 'thumbs' directory and all its contents from your web server should you not 
    have the correct permissions to do so via FTP<br>
    <br>";
    if (!is_dir_empty('thumbs')) {
        echo "The 'thumbs' directory exists and is not empty - <a href='?deleted'>Click here to confirm deletion</a>.";
    } else {
        if (file_exists('thumbs')) {
            echo "The 'thumbs' directory exists, but contains no files. You should be able to delete the 'thumbs' directory via FTP, for security reasons delete this file.";
        } else {
            echo "The 'thumbs' directory could not be found, please check you have placed the uninstall script in the correct location.
            The file structure should be like so:<br>
            thumbs<br>
            |_contents of thumbs dir
            uninstall.php";
        }
    }
}
if ($mode == 'deleted') {
    system('rm -Rf thumbs/*');
    if (!is_dir_empty('thumbs')) {
        echo "There was an error removing all the contents from the 'thumbs' directory, please go back and try again. If the problem persists you may need
        to contact your web host administrator.";
    } else {
        echo "All the contents from the 'thumbs' directory was successfully deleted, you will need to manually remove the empty 'thumbs' directory, for security reasons delete this file.";
    }
}
?>